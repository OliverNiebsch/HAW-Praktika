%%%-------------------------------------------------------------------
%%% @author Oliver
%%% @copyright (C) 2015, <COMPANY>
%%% @doc
%%%
%%% @end
%%% Created : 21. Apr 2015 08:30
%%%-------------------------------------------------------------------
-module(client).
-define(newline, "\n").
-import(werkzeug, [get_config_value/2,logging/2,logstop/0,openSe/2,openSeA/2,openRec/3,openRecA/3,createBinaryS/1,createBinaryD/1,createBinaryT/1,createBinaryNS/1,concatBinary/4,message_to_string/1,shuffle/1,timeMilliSecond/0,reset_timer/3,compareNow/2,getUTC/0,compareUTC/2,now2UTC/1,type_is/1,to_String/1,bestimme_mis/2,testeMI/2]).

%% API
-export([start/0]).

start() ->
  {ok, ConfigListe} = file:consult("client.cfg"),
  {ok, Clients} = get_config_value(clients, ConfigListe),
  start(Clients).

start(0) -> [];
start(Clients) ->
  ClientPid = spawn(fun() -> startSingleClient(Clients) end),
  [ClientPid | start(Clients - 1)].

startSingleClient(ClientNr) ->
  % 2.3.1 1: loadConfiguration
  {Servernode, Servername, Sleeptime, LifetimeMs, Suffix} = loadConfiguration(),

  net_adm:ping(Servernode),

  % 3.1.2 Lebenszeit setzen
  {ok, _Timer} = timer:kill_after(LifetimeMs, self()),

  ClientLog = "client_" ++ werkzeug:to_String(ClientNr) ++ werkzeug:to_String(node()) ++ ".log",
  loop({Servername, Servernode}, ClientLog, Sleeptime, 5, [], Suffix)
.

loop(ServerPID, Logfile, Sleeptime, NumberOfMsgs, RedakteurMsgs, Suffix) ->
  % 3.1.1 5 Nachrichten schreiben
  {NewSleeptime, RedakteurMsgs2} = redakteur(ServerPID, Logfile, Sleeptime, 5),
  NewRedakteurMsgs = RedakteurMsgs ++ RedakteurMsgs2,

  % 3.1.1 Abfragen aktueller Nachrichten
  UpdatedRedakteurMsgs = leser(ServerPID, Logfile, NewRedakteurMsgs, Suffix),

  loop(ServerPID, Logfile, NewSleeptime, NumberOfMsgs, UpdatedRedakteurMsgs, Suffix)
.

loadConfiguration() ->
  {ok, ConfigListe} = file:consult("client.cfg"),
  {ok, Servernode} = get_config_value(servernode, ConfigListe),
  {ok, Servername} = get_config_value(servername, ConfigListe),
  {ok, Sendinterval} = get_config_value(sendeintervall, ConfigListe),
  {ok, Lifetime} = get_config_value(lifetime, ConfigListe),
  {ok, Suffix} = get_config_value(selfmsgsuffix, ConfigListe),
  {Servernode, Servername, Sendinterval*1000, Lifetime*1000, Suffix}.


% Redakteur Rolle
redakteur(ServerPID, Logfile, Sleeptime, 0) ->
  % 3.1.1 Wir fragen noch mal eine MsgID ab, schicken aber keine Nachricht
  ServerPID ! {self(), getmsgid},
  receive
    {nid, Number} -> NNr = Number
  end,
  LogMsg = werkzeug:to_String(NNr) ++ "te_Nachricht um " ++ werkzeug:timeMilliSecond() ++ " vergessen zu senden\n",
  werkzeug:logging(Logfile, LogMsg),

  % 3.1.2 Zeit zwischen Nachrichten modifizieren
  NewSleeptime = changeClientMsgTime(Sleeptime, random:uniform(2) > 1),
  {NewSleeptime, []}
;

redakteur(ServerPID, Logfile, SleepTime, N) ->
  % 3.1.1 Alle X Sekunden eine Nachricht senden

  % 2.3.1 8: Nach eindeutiger MsgNr fragen
  werkzeug:logging(Logfile, "Redakteur>> Frage Server nach neuer MsgID" ++ ?newline),
  ServerPID ! {self(), getmsgid},
  receive
    {nid, Number} -> NNr = Number
  end,

  % 2.3.1 8.1.1: Nachricht verschicken
  werkzeug:logging(Logfile, "Redakteur>> Nachricht an den Server geschickt: #" ++ werkzeug:to_String(NNr) ++ ?newline),
  ServerPID ! {dropmessage, [NNr, "Eine ganz tolle Nachricht von (" ++ werkzeug:to_String(node()) ++ ")208", werkzeug:timeMilliSecond()]},
  % X Sekunden warten
  timer:sleep(SleepTime),
  {NewSleeptime, NrList} = redakteur(ServerPID, Logfile, SleepTime, N-1),
  {NewSleeptime, [NNr | NrList]}
.


% Funktionen zum Ändern des Sendeintervalls
changeClientMsgTime(Time, false) -> Time + (Time div 2);
changeClientMsgTime(Time, true) when(Time < 4000) -> 2000;
changeClientMsgTime(Time, true) -> Time div 2.


% Leser Rolle
leser(ServerPID, Logfile, RedakteurMsgs, Suffix) ->
  ServerPID ! {self(), getmessages},
  receive
    {reply,MsgList,false} ->
      NewRedakteurMsgs = logReceivedMsg(Logfile, MsgList, RedakteurMsgs, Suffix),
      leser(ServerPID, Logfile, NewRedakteurMsgs, Suffix);
    {reply,MsgList,true} ->
      NewRedakteurMsgs = logReceivedMsg(Logfile, MsgList, RedakteurMsgs, Suffix),
      NewRedakteurMsgs
  end
.

% 3.1.2 Darstellung der Nachricht in einer GUI (hier: Logfile)
logReceivedMsg(Logfile, [NNr,_Msg,TSclientout,_TShbqin,_TSdlqin,_TSdlqout], Special, Suffix) ->
  {Bool, NewSpecial} = getFromList(Special, NNr),
  case Bool of
    true ->
      LogMsg = werkzeug:to_String(self()) ++ ": " ++ werkzeug:to_String(NNr) ++ "te Nachricht. C Out: " ++ werkzeug:to_String(TSclientout) ++ " ; C In: " ++ werkzeug:timeMilliSecond() ++ werkzeug:to_String(Suffix) ++ ?newline,
      werkzeug:logging(Logfile,LogMsg);
    false ->
      LogMsg = werkzeug:to_String(self()) ++ ": " ++ werkzeug:to_String(NNr) ++ "te Nachricht. C Out: " ++ werkzeug:to_String(TSclientout) ++ " ; C In: " ++ werkzeug:timeMilliSecond() ++ ?newline,
      werkzeug:logging(Logfile,LogMsg)
  end,
  NewSpecial
.

getFromList([], _Needle) -> {false, []};
getFromList([Needle | Rest], Needle) -> {true, Rest};
getFromList([Kopf | Rest], Needle) ->
  {Erg, List} = getFromList(Rest, Needle),
  {Erg, [Kopf|List]}.
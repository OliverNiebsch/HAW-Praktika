erl -name server -setcookie vsp

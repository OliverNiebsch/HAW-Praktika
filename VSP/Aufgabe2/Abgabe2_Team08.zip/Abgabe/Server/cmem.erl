-module(cmem).
-define(newline, "\n").
-compile(export_all).
-import(werkzeug,[getUTC/0, compareUTC/2, to_String/1]).

%Ref: 3.3.4
initCMEM(RemTime, Datei) ->
	LogMsg = "CMEM>>: Initialisiere CMEM mit RemTime: " ++ werkzeug:to_String(RemTime),
	werkzeug:logging(Datei, LogMsg),
	{[], RemTime}.
	

%Ref: 3.3.4
%Prüft ob der Zeitstempel noch legitim ist, oder der Client vergessen werden soll.
getClientNNr({[], _RemTime}, _ClientID) ->
	%io:format("##### getClientNNr für unbekannten Client ###\n"),
	1; % Unbekannter Client. 

getClientNNr( { [{ClientID, NNr, LastTimeAction}|_Rest], RemTime}, ClientID) ->
	CompareResult = werkzeug:compareUTC(werkzeug:getUTC(), LastTimeAction + RemTime), %before, afterw, oder concurrent
	
	%If timeout, nnr = 1
	if
		CompareResult =:= afterw ->
			ReturnValue = 1;
		true ->
			ReturnValue = NNr
	end,
	
	ReturnValue;

getClientNNr({[_Kopf|Rest],RemTime}, ClientID) ->
	getClientNNr({Rest, RemTime}, ClientID).
	
	
%Ref: 3.3.4	
%Client noch nicht vorhanden
updateClient({[], RemTime}, ClientID, NNr, Datei) ->
	LogMsg = "CMEM>>: ClientID: " ++ werkzeug:to_String(ClientID) ++ " Bisher unbekannter Client hinzugefügt mit NNr auf: " ++ werkzeug:to_String(NNr) ++ ?newline,
	werkzeug:logging(Datei, LogMsg),
	{[{ClientID, NNr, werkzeug:getUTC()}], RemTime};

updateClient({[{ClientID, _NNR, _LastTimeAction}|Rest], RemTime}, ClientID, NNr, Datei) ->
	LogMsg = "CMEM>>: ClientID: " ++ werkzeug:to_String(ClientID) ++ " NNr gesetzt auf: " ++ werkzeug:to_String(NNr) ++ ?newline,
	werkzeug:logging(Datei, LogMsg),
	{[{ClientID, NNr, werkzeug:getUTC()}| Rest], RemTime};
	
updateClient({[Kopf|Rest], RemTime}, ClientID, NNr, Datei) ->
	{RestNeu, RemTime} = updateClient({Rest, RemTime}, ClientID, NNr, Datei),
	
	{[Kopf|RestNeu], RemTime}.
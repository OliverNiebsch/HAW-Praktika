%%%-------------------------------------------------------------------
%%% @author Oliver
%%% @copyright (C) 2015, <COMPANY>
%%% @doc
%%%
%%% @end
%%% Created : 21. Apr 2015 13:40
%%%-------------------------------------------------------------------
-module(hbq).
-define(newline, "\n").
-import(dlq, [initDLQ/2, expectedNr/1, push2DLQ/3, deliverMSG/4]).
-import(werkzeug, [timeMilliSecond/0]).

%% API
-export([startHBQ/0]).

startHBQ() ->
	io:format("StartH HBQ\n"),
  loop({null, null, null}, null).

% Main-Loop für Messages
loop({Logfile, DLQLimit, ML}, DLQ) ->
  receive
    {request, initHBQ} ->
		{DLQ_, HBQ_} = init(),
		{Logfile_, _, _} = HBQ_,
		werkzeug:logging(Logfile_, "Init HBQ und DLQ\n"),
		{ok, ConfigListe} = file:consult("server.cfg"),
		{ok, Servernode} = werkzeug:get_config_value(servernode, ConfigListe),
		{ok, Servername} = werkzeug:get_config_value(servername, ConfigListe),
		net_adm:ping(Servernode),
		{Servername,Servernode} ! {reply, ok},
        loop(HBQ_, DLQ_);

    {request, pushHBQ,[NNr, Msg, TSclientout]} ->
        % 2.3.3 Nachrichten für HBQ
        MsgList = insertToHBQList(NNr, [NNr, Msg, TSclientout, werkzeug:timeMilliSecond()], ML),

        % !Änderung!
        %% Erst auf erwartete Nachricht prüfen und dann Fehlernachricht erzeugen
        %% und dann noch mal prüfen, um Fehlernachricht zu übertragen

        % 2.3.3 erwartete Nachricht & Nachricht in DLQ
        {NewDLQ, NewMsgList} = allMsgs2DLQ(MsgList, DLQ, Logfile),

        % 2.3.3 Fehlernachricht
        Error = checkMsgList(DLQLimit * 2 / 3, NewMsgList, dlq:expectedNr(NewDLQ)),
        if
          Error =/= false ->
            NewDLQ2 = dlq:push2DLQ(Error, NewDLQ, Logfile),

            % 2.3.3 erwartete Nachricht & Nachricht in DLQ
            {DLQ_, MsgList_} = allMsgs2DLQ(NewMsgList, NewDLQ2, Logfile);
          true ->
            {DLQ_, MsgList_} = {NewDLQ, NewMsgList}
        end,
        loop({Logfile, DLQLimit, MsgList_}, DLQ_);

    {request, deliverMSG, NNr, ToClient} ->
        % 2.3.3 HBQ-Prozess
        dlq:deliverMSG(NNr, ToClient, DLQ, Logfile),
        loop({Logfile, DLQLimit, ML}, DLQ);

    {request, dellHBQ} ->
        exit("dell request")
  end
.

init() ->
  {ok, ConfigListe} = file:consult("server.cfg"),
  {ok, DLQLimit} = werkzeug:get_config_value(dlqlimit, ConfigListe),
  Logfile = "HB-DLQ@" ++ werkzeug:to_String(node()) ++ ".log",

  DLQ = dlq:initDLQ(DLQLimit, Logfile),
  HBQ = {Logfile, DLQLimit, []},
  {DLQ, HBQ}
.

% 2.3.3 erwartete Nachricht & Nachricht in DLQ (!Änderung! gleich alle verfügbaren)
allMsgs2DLQ([], DLQ, _) -> {DLQ, []};
allMsgs2DLQ([{NNr, Msg} | RestList], DLQ, Logfile) ->
  ExpectedNNr = dlq:expectedNr(DLQ),
  %werkzeug:logging(Logfile, "DLQ erwartet #" ++ werkzeug:to_String(ExpectedNNr) ++ ", HBQ hat " ++ werkzeug:to_String(NNr) ++ ?newline),
  if
    NNr =:= ExpectedNNr ->
      % erwartete Nachricht ist in HBQ vorhanden
      NewDLQ = dlq:push2DLQ(Msg, DLQ, Logfile),
      allMsgs2DLQ(RestList, NewDLQ, Logfile);
    true ->
      % erwartete Nachricht nicht gefunden
      {DLQ, [{NNr, Msg} | RestList]}
  end
.

% 2.3.3 Fehlernachricht
checkMsgList(CriticalSize, MsgList, Expected) when length(MsgList) > CriticalSize ->
  [{NNr, _M}|_R] = MsgList,
  TS = werkzeug:timeMilliSecond(),
  [NNr-1, "! Fehlernachricht für die Nachrichten " ++ werkzeug:to_String(Expected) ++ " bis " ++ werkzeug:to_String(NNr-1) ++ "!", TS, TS]
  ;

checkMsgList(_CriticalSize, _MsgList, _E) -> false.


% Sortiertes Einfügen der Nachricht in die Liste
insertToHBQList(Nr, Elem, []) ->
  [{Nr, Elem}];

insertToHBQList(Nr, Elem, [{NNr, Msg}|Rest]) when Nr < NNr ->
  [{Nr, Elem}, {NNr, Msg}] ++ Rest;

insertToHBQList(Nr, Elem, [Tupel|Rest]) ->
  [Tupel|insertToHBQList(Nr, Elem, Rest)].
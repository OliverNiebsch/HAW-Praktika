-module(dlq).
-define(newline, "\n").
-compile(export_all).
-import(werkzeug,[timeMilliSecond/0, logging/2, to_String/1]).

  %LogMsg = [NNr] ++ "te_Nachricht um " ++ werkzeug:timeMilliSecond() ++ " vergessen zu senden",
  %werkzeug:logging(Logfile, LogMsg),


%3.5.3
initDLQ(MaxSize, Datei) ->
	LogMsg = "DLQ>>: Initialisiere DLQ mit MaxSize: " ++ werkzeug:to_String(MaxSize) ++ ?newline,
	werkzeug:logging(Datei, LogMsg),
	{ok, ConfigListe} = file:consult("server.cfg"),
	{ok, Servernode} = werkzeug:get_config_value(servernode, ConfigListe),
	{ok, Servername} = werkzeug:get_config_value(servername, ConfigListe),
	{[], MaxSize, {Servername, Servernode}}.

	
expectedNr({[],_Msg, _ServerPID}) ->
	1;
	
%3.5.3
expectedNr({Queue, _MaxSize, _ServerPID}) ->
% last elem
	{NNr, _Msg} = lists:last(Queue),
	NNr + 1.
	

%Gelöscht wird immer vorne. Angehängt wird immer hinten.
%3.5.3
push2DLQ([NNr, Msg, Tsclientout, Tshbqin], {Queue, MaxSize, ServerPID}, Datei) ->
	TSDLQIn = werkzeug:timeMilliSecond(),
	%Queue  = [{MSGNr, Msg}, ..., n-th]
	NewElem = {NNr, [NNr, Msg, Tsclientout, Tshbqin, TSDLQIn]},
	DLQLength = length(Queue),
	
	if
		DLQLength > MaxSize ->		
			[_DeletedOldestElem|RestQueue] = Queue,
			QueueNeu = RestQueue ++ [NewElem],
			LogMsg = "DLQ>>: Push2DLQ: "++ werkzeug:to_String([NNr, Msg, Tsclientout, Tshbqin, TSDLQIn]) ++" (aeltestes Element gelöscht)\n",
			werkzeug:logging(Datei, LogMsg);
			%lists:keyreplace(MinNNr, 1, Queue, NewElem);
		true ->
			QueueNeu = Queue ++ [NewElem],
			LogMsg = "DLQ>>: Push2DLQ: "++ werkzeug:to_String([NNr, Msg, Tsclientout, Tshbqin, TSDLQIn]) ++ ?newline,
			werkzeug:logging(Datei, LogMsg)
	end,		
	{QueueNeu, MaxSize, ServerPID}.
	
%3.5.3
deliverMSG(MSGNr, ClientPID, {[], _MaxSize, ServerPID}, Datei) ->
	Message = [-1,"Keine Nachrichten da","","",""],	%TS von DLQ wird noch angehängt, deswegen nur 3 leere TS
	TSDLQOut = werkzeug:timeMilliSecond(),
	
	MessageNeu = Message ++ [TSDLQOut],
	ClientMessageTuple = {reply, MessageNeu, true},
	LogMsg = "DLQ>>: deliverMSG: "++ werkzeug:to_String(ClientMessageTuple) ++ " :: an Client:: " ++ werkzeug:to_String(ClientPID) ++ ?newline,
	werkzeug:logging(Datei, LogMsg),
	
	ServerPID ! {reply, MSGNr-1},
	ClientPID ! ClientMessageTuple;

deliverMSG(MSGNr, ClientPID, {Queue, _MaxSize, ServerPID}, Datei) ->
	{Last_NNr, _} = lists:last(Queue),
	[FirstMsg | _Rest] = Queue,
	{First_NNr, _} = FirstMsg,
	
	LogMsg2 = "DLQ>>: gefragt nach NNr: "++ werkzeug:to_String(MSGNr) ++ " :: für Client:: " ++ werkzeug:to_String(ClientPID) ++ ". Habe Nachrichten in " ++ werkzeug:to_String({First_NNr, Last_NNr}) ++ ?newline,
	werkzeug:logging(Datei, LogMsg2),
	
	if
		Last_NNr < MSGNr ->
			{NNr, Message} = {MSGNr - 1, [-1,"Keine Nachrichten da","","",""]};	%TS von DLQ wird noch angehängt, deswegen nur 3 leere TS
		First_NNr > MSGNr ->
			{NNr, Message} = FirstMsg;
		true ->
			{NNr, Message} = findNextMsg(Queue, MSGNr)
	end,
	
	if
		Last_NNr < MSGNr ->
			TerminateFlag = true;
		Last_NNr =:= MSGNr ->
			TerminateFlag = true;
		true ->
			TerminateFlag = false
	end,
	
	TSDLQOut = werkzeug:timeMilliSecond(),
	
	MessageNeu = Message ++ [TSDLQOut],
	ClientMessageTuple = {reply, MessageNeu, TerminateFlag},
	LogMsg = "DLQ>>: deliverMSG: "++ werkzeug:to_String(ClientMessageTuple) ++ " :: an Client:: " ++ werkzeug:to_String(ClientPID) ++ ?newline,
	werkzeug:logging(Datei, LogMsg),
	
	ServerPID ! {reply, NNr},
	ClientPID ! ClientMessageTuple.

findNextMsg(Queue, NNr) ->
  Msg = lists:keyfind(NNr, 1, Queue),
  if
    Msg =:= false ->
	findNextMsg(Queue, NNr + 1);
    true ->
	Msg
  end.





-module(server).
-define(newline, "\n").
-compile(export_all).
-import(werkzeug,[get_config_value/2, to_String/1]).
-import(cmem, [initCMEM/2, updateClient/4, getClient/2, getClientNNr/2]).
-import(hbq, [startHBQ/0]).


%c(werkzeug), c(cmem), c(server), c(hbq), c(dlq).


start() ->
	DateiServerLog = "Server@" ++ werkzeug:to_String(node()) ++ ".log",
	
	LogMsg = "SERVER>>: Lade CFG Values\n",
	werkzeug:logging(DateiServerLog, LogMsg),
	
	Name = readCfg(servername), %loadConfiguration % ref 2.3.1
	RemTime = readCfg(cmemremtime),
	HBQNode = readCfg(hbqnode),
	ServerLifetime = readCfg(serverlifetime),
	
	CMEM = cmem:initCMEM(RemTime, DateiServerLog),
	
	LogMsg2 = "SERVER>>: Spawn HBQ\n",
	werkzeug:logging(DateiServerLog, LogMsg2),	
	HBQPid = spawn(HBQNode ,fun() -> startHBQ() end),

	LogMsg3 = "SERVER>>: Spawn Receive Block\n",
	werkzeug:logging(DateiServerLog, LogMsg3),
	ServerPid = spawn(fun() -> receiveBlock(CMEM, 1, HBQPid, ServerLifetime, DateiServerLog) end),
	register(Name,ServerPid),
	
	HBQPid ! {request, initHBQ}, % Ref 3.4.3  / init hbq	
	ServerPid.


readCfg(Command) ->
	% Beispielaufruf: 	{ok, ConfigListe} = file:consult("server.cfg"),
	%{ok, Lifetime} = get_config_value(lifetime, ConfigListe),
	{ok, ConfigListe} = file:consult("server.cfg"),
	{ok, Result} = werkzeug:get_config_value(Command, ConfigListe),
	Result.
	
receiveBlock(CMEM, CurNNr, HBQPid, ServerLifetime, DateiServerLog) ->
     % Ref: Entwurf: 3.2.3.
	 receive
		{Client, getmsgid} ->			
			Client ! {nid, CurNNr},
			
			NextNNr = CurNNr + 1,
			%io:format("CurNNr:~p\n", [CurNNr]),
			receiveBlock(CMEM, NextNNr, HBQPid, ServerLifetime, DateiServerLog);
		{Client, getmessages} -> 
			Nr = cmem:getClientNNr(CMEM, Client),
			LogMsg = "SERVER>>: Client " ++ werkzeug:to_String(Client) ++ " fragt nach Nachrichten. Kriegt Nachricht #" ++ werkzeug:to_String(Nr) ++ ?newline,
			werkzeug:logging(DateiServerLog, LogMsg),
			HBQPid ! {request, deliverMSG, Nr, Client},
			receive
				{reply, SendNNr} -> 
					CMEMNeu = cmem:updateClient(CMEM, Client, SendNNr + 1, DateiServerLog),
					receiveBlock(CMEMNeu, CurNNr, HBQPid, ServerLifetime, DateiServerLog)
			after
				ServerLifetime -> killme(HBQPid, ServerLifetime, DateiServerLog)
			end;

		{dropmessage, Message} -> 
			%Forward to HBQ: hbq:deliverMSG (Ref 2.3.2)
			HBQPid ! {request, pushHBQ, Message},
			receiveBlock(CMEM, CurNNr, HBQPid, ServerLifetime, DateiServerLog);
			
		{reply, ok} -> 
			werkzeug:logging(DateiServerLog, "SERVER>>: HBQ Initialized\n"),
			receiveBlock(CMEM, CurNNr, HBQPid, ServerLifetime, DateiServerLog);
		
		Any ->
			io:format("Received Something wrong:~p\n", [Any]),
			receiveBlock(CMEM, CurNNr, HBQPid, ServerLifetime, DateiServerLog)
	 after
		ServerLifetime -> killme(HBQPid, ServerLifetime, DateiServerLog)
	 end.

killme(HBQPid, ServerLifetime, DateiServerLog) ->
	HBQPid ! {request, dellHBQ},
	LogMsg = "SERVER>>: No MSG Received for " ++ werkzeug:to_String(ServerLifetime) ++?newline,
	werkzeug:logging(DateiServerLog, LogMsg).
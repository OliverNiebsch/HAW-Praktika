README:



###################
Starten der HBQ (Dateien liegen im Unterordner Server):
1. Anpassen der Konfiguration (server.cfg) auf das jeweilige System. (Eintragen von: servername, servernode...))

2. Ausführung einer ErlangNode aus dem jeweiligen Ordner mit gewünschtem Namen und Cookie
	In Linux z.B. über "sh runHBQ.sh" (Vorrausgesetzt die Shell befindet sich im Ordner der hbq.erl)
	Alternativ:
		erl -name hbqNode -setcookie vsp

3. Compilieren der Module:
	c(werkzeug), c(hbq), c(dlq).
4. Starten erfolgt durch den entfernten Aufruf des Servers.


###################
Starten des Servers (Dateien liegen im Unterordner Server): 

!Achtung: Vor dem Starten muss die HBQ bereits laufen.!

1. Anpassen der Konfiguration (server.cfg) auf das jeweilige System. (z.B. Eintragen von: hbqname und hbqnode)

2. Ausführung einer ErlangNode aus dem jeweiligen Ordner mit gewünschtem Namen und Cookie
	In Linux z.B. über "sh runServer.sh" (Vorrausgesetzt die Shell befindet sich im Ordner der server.erl)
	Alternativ:
		erl -name server -setcookie vsp

3. Compilieren der Module:
	c(werkzeug), c(cmem), c(server), c(hbq), c(dlq).
4. Starten des Servers:
	server:start().


##################
Starten des Clients (Dateien liegen im Unterordner Client):

1. Anpassen der Konfiguration (client.cfg) auf das jeweilige System und Server. (z.B Eintragen von: servername und servernode)
2. Ausführung einer ErlangNode mit gewünschtem Namen und Cookie.
	In Linux z.B. über "sh runClient.sh" (Vorrausgesetzt die Shell befindet sich im Ordner der client.erl)
	Alternativ:
		erl -name client -setcookie vsp
3. Compilieren der Module:
	c(werkzeug), c(client).
4. Starten des Clients:
	client:start().
##################
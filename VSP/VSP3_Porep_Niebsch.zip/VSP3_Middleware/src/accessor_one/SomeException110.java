package accessor_one;

public class SomeException110 extends Exception {
	private static final long serialVersionUID = 1L;

	public SomeException110(String message) {
		super(message);
	}
}

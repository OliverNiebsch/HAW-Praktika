package accessor_two;

public class SomeException112 extends Exception {
	private static final long serialVersionUID = 1L;

	public SomeException112(String message) {
		super(message);
	}
}

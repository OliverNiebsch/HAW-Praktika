package accessor_two;

public class SomeException304 extends Exception {
	private static final long serialVersionUID = 1L;

	public SomeException304(String message) {
		super(message);
	}
}

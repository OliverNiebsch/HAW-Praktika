~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#                           __                             #
#                          /\ \                            #
#    _ __    __     __     \_\ \    ___ ___      __        #
#   /\`'__\/'__`\ /'__`\   /'_` \ /' __` __`\  /'__`\      #
#   \ \ \//\  __//\ \ \.\_/\ \ \ \/\ \/\ \/\ \/\  __/      #
#    \ \_\\ \____\ \__/.\_\ \___,_\ \_\ \_\ \_\ \____\     #
#     \/_/ \/____/\/__/\/_/\/__,_ /\/_/\/_/\/_/\/____/     #
 ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___ 
(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)

 1. Wechseln in das bin-Verzeichnis:

    Die compilierten .class-Dateien befinden sich im
    bin-Verzeichnis des entpackten .zip-Archivs. Die Klassen-
    Dateien befinden sich im src-Verzeichnis.
    Zum Starten der Anwendung, muss man sich im bin-
    Verzeichnis befinden.

------------------------------------------------------------

 2. Starten des Namensservers:
 
    java name_service/Starter <port>
------------------------------------------------------------

 Anschlie�end k�nnen die Testanwendungen ausgef�hrt werden. 

------------------------------------------------------------
 3. Starten der mitgelieferten Testanwendung:
 3.1) Server:
    java testcase/lpon_server/Server <host> <port> 

 3.2) Client:
    java testcase/lpon_client/Client <host> <port>
 
 ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___  ___ 
(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)(___)